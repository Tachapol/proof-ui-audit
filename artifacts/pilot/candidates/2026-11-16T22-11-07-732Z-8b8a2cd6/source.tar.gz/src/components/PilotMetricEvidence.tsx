import type { PilotMetricResult } from '@/lib/schema/pilot-metric';

const labels = { 'touch-target-spacing': 'Touch Target Spacing', 'heading-hierarchy': 'Heading Hierarchy' };

export function PilotMetricEvidence({ results }: { results?: PilotMetricResult[] }) {
  if (!results?.length) return null;
  return (
    <section aria-labelledby="pilot-metric-heading" className="space-y-3 rounded-xl border border-zinc-200 bg-white p-4">
      <h3 id="pilot-metric-heading" className="font-semibold text-zinc-900">Pilot metric evidence</h3>
      <p className="text-xs text-zinc-600">Project advisories only. Below 8 CSS px and deeper heading skips request context review; they do not establish WCAG failure. Execution and applicability are separate from the finding outcome.</p>
      {results.map((result, index) => (
        <div key={`${result.metricId}-${index}`} className="space-y-2 border-t border-zinc-100 pt-3" data-metric-id={result.metricId}>
          <h4 className="text-sm font-semibold">{labels[result.metricId]} <span className="font-normal text-zinc-600">v{result.metricVersion} · {result.viewport.width}×{result.viewport.height} · {result.unit}</span></h4>
          <dl className="flex flex-wrap gap-x-5 gap-y-1 text-xs">
            <div><dt className="inline font-semibold">Execution: </dt><dd className="inline">{result.executionStatus}</dd></div>
            <div><dt className="inline font-semibold">Applicability: </dt><dd className="inline">{result.applicability}</dd></div>
            <div><dt className="inline font-semibold">Outcome: </dt><dd className="inline">{result.outcome ?? 'Not assessed'}</dd></div>
          </dl>
          <p className="text-xs text-zinc-600">{result.reason}</p>
          <p className="text-xs text-zinc-600">UI scope: <code>{result.scopeSelector ?? 'Unavailable'}</code>{result.parentHeadingLevel !== undefined ? ` · Parent heading: ${result.parentHeadingLevel}` : ''}</p>
          <details className="text-xs">
            <summary className="cursor-pointer font-medium">Raw metric evidence ({result.measurements.length})</summary>
            <p className="mt-2 text-zinc-600">null means unavailable or no comparable pair; it does not mean 0. Measurements retain DOM order, target pairs and bounding boxes.</p>
            <pre className="mt-2 max-h-96 overflow-auto whitespace-pre-wrap break-all rounded bg-zinc-50 p-3">{JSON.stringify(result.measurements, null, 2)}</pre>
            <ul className="mt-2 list-disc space-y-1 pl-5 text-zinc-600">{result.limitations.map(text => <li key={text}>{text}</li>)}</ul>
          </details>
        </div>
      ))}
    </section>
  );
}
