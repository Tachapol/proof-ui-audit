import { captureIssueEvidence } from './screenshot-evidence';
import { chromium, Browser, Page, BrowserContext } from '@playwright/test';
import path from 'path';
import fs from 'fs/promises';
import { TargetMeasurement, evaluateTargetSize, checkSpacingAlternative } from './rules/target-size';
import { TextContrastMeasurement, evaluateTextContrast } from './rules/text-contrast';
import { NonTextContrastMeasurement, evaluateNonTextContrast } from './rules/non-text-contrast';
import { evaluateTextSpacing } from './rules/text-spacing';
import { evaluateReflow } from './rules/reflow';
import { extractReflowMeasurement } from './reflow-extraction';
import { compositeLayers, blendColors, applyElementOpacity, parseColor } from './color-math';
import { isPrivateOrReservedIP } from './url-validator';
import { UXIssue, Viewport } from '@/lib/schema/ux-issue';
import { ProductContext } from '@/lib/schema/product-context';
import type { PilotScope, PilotMetricResult } from '@/lib/schema/pilot-metric';
import { extractPilotFromPage } from './pilot-browser';
import { evaluateTouchTargetSpacing, evaluateHeadingHierarchy, unavailablePilotMetric, PILOT_METRIC_IDS } from './pilot-metrics';

const SCREENSHOTS_DIR = path.resolve(process.cwd(), 'public/screenshots');

export interface AuditOptions {
  pilotScope?: PilotScope;
  enablePilotMetrics?: boolean;
  url: string;
  viewports?: Viewport[];
  timeoutMs?: number;
  captureScreenshots?: boolean;
  captureIssueScreenshots?: boolean;
  localOrigin?: string;
}

export const DEFAULT_AUDIT_VIEWPORTS: Viewport[] = [
  { width: 1440, height: 900 },  // Desktop (Default)
  { width: 375, height: 667 },   // Mobile
  { width: 320, height: 640 },   // Reflow boundary; evaluate Reflow only at this width.
];

async function ensureScreenshotDir() {
  await fs.mkdir(SCREENSHOTS_DIR, { recursive: true });
}

export async function runBrowserAudit(options: AuditOptions): Promise<{
  issues: UXIssue[];
  errors: string[];
  pageScreenshots: Array<{ width: number; height: number; path: string }>;
  detectedContext?: Partial<ProductContext>;
  metricResults: PilotMetricResult[];
}> {
  await ensureScreenshotDir();
  const issues: UXIssue[] = [];
  const errors: string[] = [];
  const metricResults: PilotMetricResult[] = [];
  const pageScreenshots: Array<{ width: number; height: number; path: string }> = [];
  let detectedContext: Partial<ProductContext> | undefined = undefined;
  const viewports = options.viewports || DEFAULT_AUDIT_VIEWPORTS;
  const timeout = options.timeoutMs || 25000;

  let browser: Browser | null = null;

  try {
    browser = await chromium.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
    });

    for (const viewport of viewports) {
      let context: BrowserContext | null = null;
      let page: Page | null = null;

      try {
        context = await browser.newContext({
          viewport: { width: viewport.width, height: viewport.height },
          deviceScaleFactor: 1,
          serviceWorkers: 'block',
        });

        await context.routeWebSocket('**', socket => socket.close());
        page = await context.newPage();
        page.setDefaultTimeout(timeout);

        // Redirect-aware & Network SSRF protection (Item A.2, A.3)
        let ssrfViolation: string | null = null;

        // Route interception to block private/internal requests & redirects
        await page.route('**', (route) => {
          const reqUrl = route.request().url();
          try {
            const parsed = new URL(reqUrl);
            const host = parsed.hostname.toLowerCase();
            const optionsUrl = new URL(options.url);
            const isLocalHost = (h: string) => h === 'localhost' || h === '127.0.0.1' || h === '[::1]';
            const isFixtureOrigin =
              parsed.origin === optionsUrl.origin ||
              (options.localOrigin && parsed.origin === options.localOrigin) ||
              (isLocalHost(host) && isLocalHost(optionsUrl.hostname) && parsed.port === optionsUrl.port);

            // Block any audited page (sandbox snippet or external site) from accessing internal application APIs
            if (parsed.pathname.startsWith('/api/')) {
              const isInitialNavigation = route.request().isNavigationRequest() && reqUrl === options.url;
              if (!isInitialNavigation) {
                return route.abort('blockedbyclient');
              }
            }

            // Allow local fixture endpoints if navigated from test server
            const isFixtureRequest =
              optionsUrl.pathname.startsWith('/fixtures/') &&
              isFixtureOrigin &&
              (parsed.pathname.startsWith('/fixtures/') || parsed.pathname.startsWith('/_next/') || parsed.pathname === '/favicon.ico');

            if (!isFixtureRequest && parsed.origin !== options.localOrigin) {
              if (host === 'localhost' || host.endsWith('.localhost') || isPrivateOrReservedIP(host)) {
                ssrfViolation = `Blocked SSRF target: ${host}`;
                return route.abort('blockedbyclient');
              }
            }
          } catch {
            return route.abort('blockedbyclient');
          }
          route.continue();
        });

        page.on('response', (res) => {
          const status = res.status();
          if (status >= 300 && status < 400) {
            const location = res.headers()['location'];
            if (location) {
              try {
                const targetUrl = new URL(location, res.url());
                const targetHost = targetUrl.hostname.toLowerCase();
                const optionsUrl = new URL(options.url);
                const isLocalHost = (h: string) => h === 'localhost' || h === '127.0.0.1' || h === '[::1]';
                const isFixtureLocation =
                  optionsUrl.pathname.startsWith('/fixtures/') &&
                  (targetUrl.origin === optionsUrl.origin ||
                    (options.localOrigin && targetUrl.origin === options.localOrigin) ||
                    (isLocalHost(targetHost) && isLocalHost(optionsUrl.hostname) && targetUrl.port === optionsUrl.port)) &&
                  targetUrl.pathname.startsWith('/fixtures/');

                if (!isFixtureLocation && targetUrl.origin !== options.localOrigin) {
                  if (targetHost === 'localhost' || targetHost.endsWith('.localhost') || isPrivateOrReservedIP(targetHost)) {
                    ssrfViolation = `Redirected to disallowed private address: ${targetHost}`;
                  }
                }
              } catch {
                // ignore URL parse errors
              }
            }
          }
        });

        const response = await page.goto(options.url, {
          waitUntil: 'domcontentloaded',
          timeout,
        });

        if (ssrfViolation) {
          errors.push(`Blocked navigation: ${ssrfViolation} on ${viewport.width}px.`);
          continue;
        }

        if (!response || !response.ok()) {
          errors.push(`Failed to load ${options.url} at ${viewport.width}px (HTTP ${response?.status() || 'No response'})`);
          continue;
        }

        await page.waitForTimeout(300);

        if (viewport.width === 320) {
          try {
            const measurement = await page.evaluate(extractReflowMeasurement, { viewport, selector: options.pilotScope?.selector });
            issues.push(...evaluateReflow(measurement, options.url));
          } catch (error) {
            errors.push(`Reflow extraction at 320px failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
          }
        }

        // Pilot metrics share one immutable snapshot, before text-spacing overrides.
        if (options.enablePilotMetrics !== false) {
          try {
            const snapshot = await extractPilotFromPage(page, options.pilotScope);
            for (const evaluate of [evaluateTouchTargetSpacing, evaluateHeadingHierarchy]) {
              const evaluation = evaluate(snapshot, options.url, viewport);
              metricResults.push(evaluation.result);
              issues.push(...evaluation.issues);
            }
          } catch (err) {
            const message = err instanceof Error ? err.message : 'Pilot extraction failed.';
            for (const id of PILOT_METRIC_IDS) {
              if (!metricResults.some(r => r.metricId === id && r.viewport.width === viewport.width && r.viewport.height === viewport.height)) {
                metricResults.push(unavailablePilotMetric(id, options.url, viewport, 'error', message, options.pilotScope?.selector));
              }
            }
            errors.push(`Pilot metrics at ${viewport.width}px: ${message}`);
          }
        }

        if (!detectedContext) {
          try {
            detectedContext = await page.evaluate(() => {
              const getMeta = (selectors: string[]) => {
                for (const sel of selectors) {
                  const el = document.querySelector(sel);
                  if (el) {
                    const content = el.getAttribute('content');
                    if (content && content.trim()) return content.trim();
                  }
                }
                return '';
              };

              const title = (document.title || '').trim();
              const description = getMeta([
                'meta[name="description"]',
                'meta[property="og:description"]',
                'meta[name="twitter:description"]',
              ]);
              const siteName = getMeta([
                'meta[property="og:site_name"]',
                'meta[name="application-name"]',
              ]);
              const rawKeywords = getMeta(['meta[name="keywords"]']);
              const themeColor = getMeta([
                'meta[name="theme-color"]',
                'meta[name="msapplication-TileColor"]',
              ]);

              const lang = document.documentElement.lang || 'en';

              const productGoal = description
                ? (title ? `${title}: ${description}` : description).slice(0, 1000)
                : (title ? title.slice(0, 1000) : '');

              const brandKeywords = [siteName, rawKeywords].filter(Boolean).join(', ').slice(0, 300);

              let validThemeColor = '';
              if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(themeColor)) {
                validThemeColor = themeColor;
              }

              const targetAudience = lang && lang !== 'en'
                ? `Web users (${lang})`
                : 'General web audience';

              return {
                productGoal,
                brandKeywords,
                themeColor: validThemeColor,
                targetAudience,
                additionalContext: 'Auto-detected from page metadata during audit.',
              };
            });
          } catch {
            // non-fatal metadata extraction
          }
        }

        if (options.captureScreenshots !== false) {
          const filename = `page-${viewport.width}-${crypto.randomUUID()}.png`;
          await page.screenshot({path:path.join(SCREENSHOTS_DIR,filename),fullPage:false});
          pageScreenshots.push({width:viewport.width,height:viewport.height,path:`/screenshots/${filename}`});
        }

        const captureIssueScreenshot = (issue: UXIssue) =>
          captureIssueEvidence(page!, issue, SCREENSHOTS_DIR, options.captureScreenshots !== false && options.captureIssueScreenshots !== false);

        for (const issue of issues.filter(issue => (issue.metric || issue.ruleId === 'reflow') && issue.viewport.width === viewport.width && issue.viewport.height === viewport.height)) {
          await captureIssueScreenshot(issue);
        }

        // 1. Measure Target Size candidates
        const rawTargets: TargetMeasurement[] = await page.evaluate(() => {
          const interactiveSelectors = [
            'button',
            'a[href]',
            'input[type="button"]',
            'input[type="submit"]',
            'input[type="reset"]',
            '[role="button"]',
            '[role="link"]',
            'summary',
          ];

          const elements = Array.from(document.querySelectorAll(interactiveSelectors.join(', ')));
          const measurements: any[] = [];

          function getSelector(el: Element): string {
            if (el.id) return `#${el.id}`;
            let path = el.tagName.toLowerCase();
            if (el.className && typeof el.className === 'string') {
              const classes = el.className.trim().split(/\s+/).slice(0, 2).join('.');
              if (classes) path += `.${classes}`;
            }
            return path;
          }

          for (const el of elements) {
            const rect = el.getBoundingClientRect();
            const style = window.getComputedStyle(el);

            if (
              rect.width === 0 ||
              rect.height === 0 ||
              style.display === 'none' ||
              style.visibility === 'hidden' ||
              parseFloat(style.opacity || '1') === 0 ||
              el.closest('[aria-hidden="true"]')
            ) {
              continue;
            }

            const isInline =
              style.display === 'inline' ||
              (el.parentElement ? window.getComputedStyle(el.parentElement).display === 'inline' : false);

            measurements.push({
              selector: getSelector(el),
              element: el.tagName.toLowerCase(),
              role: el.getAttribute('role') || el.tagName.toLowerCase(),
              accessibleName: el.getAttribute('aria-label') || (el.textContent || '').trim().slice(0, 50),
              width: rect.width,
              height: rect.height,
              x: rect.x,
              y: rect.y,
              isInline,
            });
          }

          return measurements;
        });

        // Compute spacing alternative geometry in Node using full verified checkSpacingAlternative
        const targetBoxes = rawTargets.map((t) => ({ x: t.x, y: t.y, width: t.width, height: t.height }));
        for (const raw of rawTargets) {
          const hasSufficientSpacing = checkSpacingAlternative(
            { x: raw.x, y: raw.y, width: raw.width, height: raw.height },
            targetBoxes
          );
          const issue = evaluateTargetSize({ ...raw, hasSufficientSpacing }, options.url, viewport);
          await captureIssueScreenshot(issue);
          issues.push(issue);
        }

        // 2. Measure Text Contrast candidates with full ancestor compositing
        const rawTexts = await page.evaluate(() => {
          const textElements = Array.from(
            document.querySelectorAll('p, h1, h2, h3, h4, h5, h6, span, label, a, button, summary, [role="heading"]')
          );
          const results: any[] = [];

          function getSelector(el: Element): string {
            if (el.id) return `#${el.id}`;
            let path = el.tagName.toLowerCase();
            if (el.className && typeof el.className === 'string') {
              const classes = el.className.trim().split(/\s+/).slice(0, 2).join('.');
              if (classes) path += `.${classes}`;
            }
            return path;
          }

          for (const node of textElements) {
            const el = node as HTMLElement;
            const style = window.getComputedStyle(el);

            // Exclusion of hidden or zero-size elements
            const rect = el.getBoundingClientRect();
            if (
              rect.width === 0 ||
              rect.height === 0 ||
              style.display === 'none' ||
              style.visibility === 'hidden' ||
              style.visibility === 'collapse' ||
              parseFloat(style.opacity || '1') === 0 ||
              el.closest('[aria-hidden="true"]')
            ) {
              continue;
            }

            // Deduplication: if element has child element nodes that contain text,
            // only evaluate direct text nodes so nested inline elements don't produce duplicates.
            let directText = '';
            const childNodes = Array.from(el.childNodes);
            const hasChildElements = childNodes.some((n) => n.nodeType === Node.ELEMENT_NODE);

            if (hasChildElements) {
              directText = childNodes
                .filter((n) => n.nodeType === Node.TEXT_NODE)
                .map((n) => n.textContent || '')
                .join('')
                .trim();
            } else {
              directText = (el.textContent || '').trim();
            }

            // Skip empty or trivial whitespace
            if (!directText || directText.length < 2) continue;

            // Collect ancestor background layers, opacities, and complex background indicators
            const bgLayers: string[] = [];
            const ancestorOpacities: number[] = [parseFloat(style.opacity || '1') || 1];
            let hasComplex = false;
            let complexReason: string | undefined = undefined;

            let curr: HTMLElement | null = el;
            while (curr && curr !== document.documentElement) {
              const currStyle = window.getComputedStyle(curr);

              if (curr.getAttribute('data-complex-bg') === 'true') {
                hasComplex = true;
                complexReason = 'Element flagged with data-complex-bg';
              }

              if (currStyle.backgroundImage && currStyle.backgroundImage !== 'none') {
                hasComplex = true;
                complexReason = `CSS background-image: ${currStyle.backgroundImage.slice(0, 50)}`;
              }

              if (currStyle.backdropFilter && currStyle.backdropFilter !== 'none') {
                hasComplex = true;
                complexReason = 'CSS backdrop-filter applied';
              }

              if (currStyle.filter && currStyle.filter !== 'none') {
                hasComplex = true;
                complexReason = 'CSS filter applied';
              }

              if (currStyle.mixBlendMode && currStyle.mixBlendMode !== 'normal') {
                hasComplex = true;
                complexReason = `CSS mix-blend-mode: ${currStyle.mixBlendMode}`;
              }

              const bg = currStyle.backgroundColor;
              if (bg && bg !== 'transparent' && bg !== 'rgba(0, 0, 0, 0)') {
                bgLayers.push(bg);
              }

              if (curr !== el) {
                const op = parseFloat(currStyle.opacity || '1');
                if (!isNaN(op)) ancestorOpacities.push(op);
              }

              curr = curr.parentElement;
            }

            // Also check documentElement / html background
            if (document.documentElement) {
              const rootStyle = window.getComputedStyle(document.documentElement);
              const rootBg = rootStyle.backgroundColor;
              if (rootBg && rootBg !== 'transparent' && rootBg !== 'rgba(0, 0, 0, 0)') {
                bgLayers.push(rootBg);
              }
            }

            results.push({
              selector: getSelector(el),
              element: el.tagName.toLowerCase(),
              role: el.getAttribute('role') || undefined,
              accessibleName: el.getAttribute('aria-label') || undefined,
              textSnippet: directText.slice(0, 60),
              fontSizePx: parseFloat(style.fontSize || '16'),
              fontWeight: style.fontWeight || '400',
              color: style.color,
              ancestorOpacities,
              bgLayers,
              hasComplex,
              complexReason,
              boundingBox: {
                x: rect.x,
                y: rect.y,
                width: rect.width,
                height: rect.height,
              },
            });
          }

          return results;
        });

        for (const raw of rawTexts) {
          // Total combined ancestor opacity
          const totalOpacity = raw.ancestorOpacities.reduce((a: number, b: number) => a * b, 1);

          // Composite background layers from top to bottom
          const { color: blendedBg, isOpaque } = compositeLayers(raw.bgLayers);

          let hasUnresolvedTransparency = false;
          let unresolvedReason: string | undefined = undefined;
          let effectiveBgStr = '#ffffff';
          let effectiveFgStr = raw.color;

          if (!isOpaque) {
            hasUnresolvedTransparency = true;
            unresolvedReason =
              'Effective background reaches document root with alpha < 1 without an opaque ancestor surface.';
          } else {
            effectiveBgStr = `rgba(${blendedBg.r}, ${blendedBg.g}, ${blendedBg.b}, ${blendedBg.a})`;

            // If foreground has alpha or totalOpacity < 1, composite it over the resolved opaque background
            const parsedFg = parseColor(raw.color);
            if (parsedFg) {
              const fgWithOpacity = applyElementOpacity(parsedFg, totalOpacity);
              if (fgWithOpacity.a < 0.999) {
                const blendedFg = blendColors(fgWithOpacity, blendedBg);
                effectiveFgStr = `rgb(${blendedFg.r}, ${blendedFg.g}, ${blendedFg.b})`;
              }
            }
          }

          const hasAncestorGroupOpacity = raw.ancestorOpacities.some((op: number) => op < 0.999);

          const measurement: TextContrastMeasurement = {
            selector: raw.selector,
            element: raw.element,
            role: raw.role,
            accessibleName: raw.accessibleName,
            textSnippet: raw.textSnippet,
            fontSizePx: raw.fontSizePx,
            fontWeight: raw.fontWeight,
            color: effectiveFgStr,
            backgroundColor: effectiveBgStr,
            hasComplexBackground: raw.hasComplex,
            hasUnresolvedTransparency,
            hasAncestorGroupOpacity,
            unresolvedReason: raw.complexReason || unresolvedReason,
            boundingBox: raw.boundingBox,
          };

          const issue = evaluateTextContrast(measurement, options.url, viewport);
          await captureIssueScreenshot(issue);
          issues.push(issue);
        }

        // 3. Measure Non-text Contrast candidates
        const rawNonText = await page.evaluate(() => {
          const components = Array.from(
            document.querySelectorAll(
              '[data-nontext-component="true"], [data-nontext-uncertain="true"], input, select, textarea, button[disabled]'
            )
          );
          const results: any[] = [];

          function getSelector(el: Element): string {
            if (el.id) return `#${el.id}`;
            return el.tagName.toLowerCase();
          }

          for (const node of components) {
            const el = node as HTMLElement;
            const rect = el.getBoundingClientRect();
            if (rect.width === 0 || rect.height === 0) continue;

            const style = window.getComputedStyle(el);
            const isUncertain = el.getAttribute('data-nontext-uncertain') === 'true';
            const isExplicitNonText = el.getAttribute('data-nontext-component') === 'true';
            const isDisabled = el.hasAttribute('disabled') || el.getAttribute('aria-disabled') === 'true';

            // Extract border color or outline color
            const borderColor = style.borderColor || '#cbd5e1';

            // If not explicit and not disabled form control, ignore
            if (!isExplicitNonText && !isUncertain && !isDisabled) {
              continue;
            }

            results.push({
              selector: getSelector(el),
              element: el.tagName.toLowerCase(),
              role: el.getAttribute('role') || el.tagName.toLowerCase(),
              accessibleName: el.getAttribute('aria-label') || el.id || 'Component Boundary',
              componentType: isUncertain ? ('graphical-object' as const) : ('ui-component-border' as const),
              indicatorColor: borderColor,
              adjacentColor: '#ffffff',
              isInactiveOrDisabled: isDisabled,
              isStateMeaningUncertain: isUncertain,
              boundingBox: {
                x: rect.x,
                y: rect.y,
                width: rect.width,
                height: rect.height,
              },
            });
          }

          return results;
        });

        for (const raw of rawNonText) {
          const issue = evaluateNonTextContrast(raw, options.url, viewport);
          await captureIssueScreenshot(issue);
          issues.push(issue);
        }

        // 4. Measure Text Spacing candidates (capture baseline, apply minimum-preserving override, capture candidate, restore)
        try {
          const baselineData = await page.evaluate(() => {
            const targets = Array.from(
              document.querySelectorAll(
                '[data-text-spacing-target="true"], [data-spacing-ambiguous="true"], [data-text-spacing-pass="true"]'
              )
            );
            const list: any[] = [];

            function getSelector(el: Element): string {
              if (el.id) return `#${el.id}`;
              return el.tagName.toLowerCase();
            }

            const docEl = document.documentElement;
            const docScrollW = docEl.scrollWidth;
            const docClientW = docEl.clientWidth;

            for (const el of targets) {
              const rect = el.getBoundingClientRect();
              const style = window.getComputedStyle(el);
              const isClipped =
                (style.overflow === 'hidden' || style.overflowY === 'hidden' || style.overflowY === 'clip') &&
                el.scrollHeight > el.clientHeight + 1.0;
              const isHorizClipped =
                (style.overflow === 'hidden' || style.overflowX === 'hidden' || style.overflowX === 'clip') &&
                el.scrollWidth > el.clientWidth + 1.0;

              // Also find adjacent controls that might get obscured
              const nextEl = el.nextElementSibling as HTMLElement | null;
              const hasAdjacentControl =
                nextEl &&
                (nextEl.tagName.toLowerCase() === 'button' ||
                  nextEl.getAttribute('role') === 'button' ||
                  nextEl.hasAttribute('data-spacing-control'));

              list.push({
                selector: getSelector(el),
                element: el.tagName.toLowerCase(),
                role: el.getAttribute('role') || undefined,
                accessibleName: el.getAttribute('aria-label') || el.id || undefined,
                textSnippet: (el.textContent || '').trim().slice(0, 60),
                isAmbiguous: el.getAttribute('data-spacing-ambiguous') === 'true',
                adjacentControlSelector: hasAdjacentControl ? getSelector(nextEl) : undefined,
                adjacentControlRect: hasAdjacentControl ? nextEl.getBoundingClientRect() : undefined,
                docScrollW,
                docClientW,
                state: {
                  width: rect.width,
                  height: rect.height,
                  scrollHeight: el.scrollHeight,
                  clientHeight: el.clientHeight,
                  scrollWidth: el.scrollWidth,
                  clientWidth: el.clientWidth,
                  isClipped,
                  isHorizontalClipped: isHorizClipped,
                  boundingBox: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
                },
              });
            }

            return list;
          });

          if (baselineData.length > 0) {
            // Apply minimum-preserving text spacing styles
            await page.evaluate(() => {
              const modified: any[] = [];
              const elements = Array.from(document.querySelectorAll('body *'));

              for (const el of elements) {
                if (!(el instanceof HTMLElement)) continue;
                const style = window.getComputedStyle(el);
                if (style.display === 'none' || style.visibility === 'hidden') continue;

                const fs = parseFloat(style.fontSize) || 16;
                let lh = parseFloat(style.lineHeight);
                if (isNaN(lh)) lh = fs * 1.2;
                let ls = parseFloat(style.letterSpacing);
                if (isNaN(ls)) ls = 0;
                let ws = parseFloat(style.wordSpacing);
                if (isNaN(ws)) ws = 0;
                let mb = parseFloat(style.marginBottom);
                if (isNaN(mb)) mb = 0;

                const reqLh = 1.5 * fs;
                const reqLs = 0.12 * fs;
                const reqWs = 0.16 * fs;
                const reqMb = 2.0 * fs;

                const origCss = el.style.cssText;
                let changed = false;

                // Minimum-preserving rule: only set if current is below required minimum!
                if (lh < reqLh - 0.05) {
                  el.style.setProperty('line-height', '1.5', 'important');
                  changed = true;
                }
                if (ls < reqLs - 0.05) {
                  el.style.setProperty('letter-spacing', '0.12em', 'important');
                  changed = true;
                }
                if (ws < reqWs - 0.05) {
                  el.style.setProperty('word-spacing', '0.16em', 'important');
                  changed = true;
                }
                if (el.tagName.toLowerCase() === 'p' && mb < reqMb - 0.05) {
                  el.style.setProperty('margin-bottom', '2em', 'important');
                  changed = true;
                }

                if (changed) {
                  modified.push({ el, originalCss: origCss });
                }
              }
              (window as any).__proofui_spacing_modified = modified;
            });

            // Brief wait for style re-layout
            await page.waitForTimeout(100);

            const candidateData = await page.evaluate(() => {
              const targets = Array.from(
                document.querySelectorAll(
                  '[data-text-spacing-target="true"], [data-spacing-ambiguous="true"], [data-text-spacing-pass="true"]'
                )
              );
              const list: any[] = [];

              function getSelector(el: Element): string {
                if (el.id) return `#${el.id}`;
                return el.tagName.toLowerCase();
              }

              const docEl = document.documentElement;
              const docScrollW = docEl.scrollWidth;
              const docClientW = docEl.clientWidth;

              for (const el of targets) {
                const rect = el.getBoundingClientRect();
                const style = window.getComputedStyle(el);
                const isClipped =
                  (style.overflow === 'hidden' || style.overflowY === 'hidden' || style.overflowY === 'clip') &&
                  el.scrollHeight > el.clientHeight + 1.0;
                const isHorizClipped =
                  (style.overflow === 'hidden' || style.overflowX === 'hidden' || style.overflowX === 'clip') &&
                  el.scrollWidth > el.clientWidth + 1.0;

                // Check bounding box escape: child bleeding outside visible container
                let isEscaped = false;
                if (style.overflow === 'visible' || (!style.overflowX && !style.overflowY)) {
                  for (const child of Array.from(el.children)) {
                    const cRect = child.getBoundingClientRect();
                    if (cRect.bottom > rect.bottom + 1.0 || cRect.right > rect.right + 1.0) {
                      isEscaped = true;
                      break;
                    }
                  }
                }

                // Check obscured adjacent control
                const nextEl = el.nextElementSibling as HTMLElement | null;
                let isControlObscured = false;
                if (nextEl && (nextEl.tagName.toLowerCase() === 'button' || nextEl.getAttribute('role') === 'button' || nextEl.hasAttribute('data-spacing-control'))) {
                  const nextRect = nextEl.getBoundingClientRect();
                  // Check intersection between el and nextEl
                  const overlapX = Math.max(0, Math.min(rect.right, nextRect.right) - Math.max(rect.left, nextRect.left));
                  const overlapY = Math.max(0, Math.min(rect.bottom, nextRect.bottom) - Math.max(rect.top, nextRect.top));
                  if (overlapX > 0 && overlapY > 0) {
                    isControlObscured = true;
                  }
                }

                list.push({
                  selector: getSelector(el),
                  docScrollW,
                  docClientW,
                  isControlObscured,
                  state: {
                    width: rect.width,
                    height: rect.height,
                    scrollHeight: el.scrollHeight,
                    clientHeight: el.clientHeight,
                    scrollWidth: el.scrollWidth,
                    clientWidth: el.clientWidth,
                    isClipped,
                    isHorizontalClipped: isHorizClipped,
                    isBoundingBoxEscaped: isEscaped,
                    boundingBox: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
                  },
                });
              }

              return list;
            });

            // Match and evaluate each candidate
            for (const base of baselineData) {
              const cand = candidateData.find((c) => c.selector === base.selector);
              if (!cand) continue;

              const isNewDocOverflow =
                base.docScrollW <= base.docClientW + 1.0 &&
                cand.docScrollW > cand.docClientW + 1.0;

              const issue = evaluateTextSpacing(
                {
                  selector: base.selector,
                  element: base.element,
                  role: base.role,
                  accessibleName: base.accessibleName,
                  textSnippet: base.textSnippet,
                  baseline: base.state,
                  candidate: cand.state,
                  isAmbiguousOverlap: base.isAmbiguous,
                  hasTextOverlap: base.isAmbiguous,
                  isControlObscured: cand.isControlObscured,
                  isNewDocumentOverflow: isNewDocOverflow,
                  obscuredControlSelector: base.adjacentControlSelector,
                },
                options.url,
                viewport
              );

              await captureIssueScreenshot(issue);
              issues.push(issue);
            }
          }
        } finally {
          // Guaranteed complete restoration: reset modified styles & clear state
          await page.evaluate(() => {
            const modified = (window as any).__proofui_spacing_modified || [];
            for (const item of modified) {
              item.el.style.cssText = item.originalCss;
            }
            delete (window as any).__proofui_spacing_modified;
            document.getElementById('proofui-text-spacing-override')?.remove();
          }).catch(() => {});
        }
      } catch (err: any) {
        errors.push(`Error auditing ${options.url} at ${viewport.width}px: ${err.message}`);
      } finally {
        // Safe browser resource cleanup on success and failure (Item A.7)
        if (page) await page.close().catch(() => {});
        if (context) await context.close().catch(() => {});
      }
    }
  } catch (err: any) {
    errors.push(`Browser launch failure: ${err.message}`);
  } finally {
    // Browser instance cleanup on success and failure (Item A.7)
    if (browser) {
      await browser.close().catch(() => {});
    }
  }

  for (const viewport of viewports) {
    for (const id of PILOT_METRIC_IDS) {
      if (!metricResults.some(r => r.metricId === id && r.viewport.width === viewport.width && r.viewport.height === viewport.height)) {
        metricResults.push(unavailablePilotMetric(id, options.url, viewport,
          options.enablePilotMetrics === false ? 'skipped' : 'error',
          options.enablePilotMetrics === false ? 'Pilot metrics excluded from this audit scope.' : 'Browser or navigation failed before pilot extraction.', options.pilotScope?.selector));
      }
    }
  }
  return { issues, errors, pageScreenshots, detectedContext, metricResults };
}
