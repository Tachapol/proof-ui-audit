import { ROLE_NAMES, type StudioSession } from './types';

export function formatStudioMarkdown(session: StudioSession): string {
  const lines: string[] = [];

  // Title & Metadata
  lines.push('# ProofUI Critique Studio Summary');
  lines.push('');
  lines.push(`- **Session ID**: \`${session.id}\``);
  lines.push(`- **Date**: ${new Date(session.createdAt).toLocaleString()}`);
  lines.push(`- **Model**: \`${session.model}\``);
  lines.push(`- **Active Roles**: ${session.roles.map(r => ROLE_NAMES[r]).join(', ')}`);
  
  if (session.runs.length > 0) {
    lines.push('- **Audited Frame(s)**:');
    session.runs.forEach(r => {
      lines.push(`  - \`${r.fixtureId ? `${r.fixtureId} (Local Fixture)` : r.targetUrl}\``);
    });
  }

  if (session.findingStats) {
    const frameText = session.findingStats.frameCount > 1 ? `across ${session.findingStats.frameCount} frames` : 'in 1 frame';
    lines.push(`- **Finding Scope**: Analyzed ${session.findingStats.analyzedCount} of ${session.findingStats.totalCandidateFindings} findings ${frameText} (Priority P0–P3 sorted)${session.findingStats.omittedCount > 0 ? ` — ${session.findingStats.omittedCount} lower-priority findings omitted` : ''}`);
  }
  lines.push('');

  // Audit Incomplete Evidence / Warnings
  if (session.auditWarnings && session.auditWarnings.length > 0) {
    lines.push('## ⚠️ Audit Warnings & Partial Evidence');
    session.auditWarnings.forEach(w => lines.push(`- ${w}`));
    lines.push('*Critique and candidates are based only on successfully measured evidence.*');
    lines.push('');
  }

  // Product Context
  const context = session.runs[0]?.productContext;
  if (context && Object.values(context).some(Boolean)) {
    lines.push('## 🎯 Product Context & Design Goals');
    if (context.productGoal) lines.push(`- **Product Goal**: ${context.productGoal}`);
    if (context.brandKeywords) lines.push(`- **Brand Keywords**: ${context.brandKeywords}`);
    if (context.themeColor) lines.push(`- **Theme Color**: \`${context.themeColor}\``);
    if (context.targetAudience) lines.push(`- **Target Audience**: ${context.targetAudience}`);
    if (context.additionalContext) lines.push(`- **Additional Context**: ${context.additionalContext}`);
    lines.push('');
  }

  // Executive Lead Summary
  if (session.leadSummary) {
    lines.push('## 🧭 Lead Coordinator Summary');
    lines.push(session.leadSummary);
    lines.push('');
  }

  // Role Summaries
  const activeRoleSummaries = Object.entries(session.roleSummaries).filter(([, summary]) => Boolean(summary));
  if (activeRoleSummaries.length > 0) {
    lines.push('## 👥 Panel Perspectives Overview');
    activeRoleSummaries.forEach(([role, summary]) => {
      lines.push(`- **${ROLE_NAMES[role as keyof typeof ROLE_NAMES] || role}**: ${summary}`);
    });
    lines.push('');
  }

  // Agenda & Detailed Findings
  if (session.agenda.length > 0) {
    lines.push('## 📋 Critique Agenda & Role Perspectives');
    lines.push('');

    session.agenda.forEach((item, index) => {
      lines.push(`### Finding ${index + 1}: ${item.title}`);
      lines.push(`- **Status**: \`${item.status}\``);
      lines.push(`- **Decision**: \`${item.decision || 'pending'}\``);

      const candidate = session.candidates[item.id];
      if (candidate) {
        const sourceText = candidate.sourceLabel ? ` (Source: ${candidate.sourceLabel})` : '';
        lines.push(`- **Color Exploration**: \`${candidate.color}\`${sourceText} (Contrast: ${candidate.beforeRatio}:1 ➔ ${candidate.afterRatio}:1, Threshold: ${candidate.threshold}:1)`);
        lines.push(`- **Verified**: ${candidate.verified ? 'Yes' : 'No'} | **Applied**: ${candidate.applied ? 'Yes' : 'No'}`);
      }
      lines.push('');

      if (item.notes.length > 0) {
        lines.push('#### Role Assessments & Trade-offs:');
        item.notes.forEach(note => {
          lines.push(`- **${ROLE_NAMES[note.role] || note.role}**:`);
          lines.push(`  - *Assessment*: ${note.comment}`);
          lines.push(`  - *Recommendation*: ${note.recommendation}`);
          if (note.tradeoff) {
            lines.push(`  - *Trade-off*: ${note.tradeoff}`);
          }
        });
        lines.push('');
      }
    });
  }

  // Discussion Transcript
  if (session.messages.length > 0) {
    lines.push('## 💬 Discussion Highlights');
    lines.push('');
    session.messages.forEach(msg => {
      const senderName = msg.sender === 'user' ? 'Reviewer (User)' : (ROLE_NAMES[msg.sender] || msg.sender);
      lines.push(`- **${senderName}**: ${msg.text}`);
    });
    lines.push('');
  }

  // Agreed Action Items
  const acceptedItems = session.agenda.filter(a => a.decision === 'accepted');
  if (acceptedItems.length > 0) {
    lines.push('## ✅ Agreed Action Items (Accepted Changes)');
    acceptedItems.forEach(item => {
      const candidate = session.candidates[item.id];
      const patchInfo = candidate ? ` -> Apply color \`${candidate.color}\`` : '';
      lines.push(`- [ ] **${item.title}**${patchInfo}`);
    });
    lines.push('');
  }

  lines.push('---');
  lines.push('*Generated by ProofUI Multi-Role Critique Studio*');

  return lines.join('\n');
}

