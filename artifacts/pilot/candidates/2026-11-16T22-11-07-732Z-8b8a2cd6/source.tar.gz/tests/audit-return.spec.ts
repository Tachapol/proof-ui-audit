import { test, expect } from '@playwright/test';
import { makeUiAuditRun } from './ui-fixtures';

test('Studio returns to the original audit, context, filter and review position after reload', async ({ page }) => {
  const run = makeUiAuditRun({
    id: 'run-return-navigation',
    productContext: { productGoal: 'Review checkout usability', brandKeywords: 'clear', themeColor: '#2563eb', targetAudience: 'Design reviewers', additionalContext: '' },
  });
  const session = {
    id: 'studio-return-navigation', version: 1, createdAt: run.timestamp,
    model: 'gpt-6-luna', runs: [run], roles: ['ux'], agenda: [],
    roleSummaries: {}, leadSummary: 'Review evidence', roleErrors: {}, messages: [], candidates: {},
  };
  await page.route('**/api/audit?*', route => {
    const id = new URL(route.request().url()).searchParams.get('id');
    return route.fulfill({ json: { success: true, run: { ...run, id } } });
  });
  await page.route('**/api/studio*', route => route.fulfill({ json: { session, sessions: [] } }));
  await page.goto(`/?runId=${run.id}`);
  await expect(page.getByRole('heading', { name: 'Audit evidence', exact: true })).toBeVisible();
  await page.getByRole('button', { name: /Show candidate fail issues/ }).click();
  const fingerprint = run.groupedIssues[0].fingerprint;
  await page.evaluate(fp => document.getElementById(`issue-card-${fp}`)?.scrollIntoView(), fingerprint);
  const position = await page.evaluate(() => window.scrollY);
  expect(position).toBeGreaterThan(0);
  await expect(page.getByRole('link', { name: 'Open Critique Studio', exact: true })).toHaveAttribute('href', `/studio?runId=${run.id}`);
  // Activate without moving the viewport to the header first.
  await page.getByRole('link', { name: 'Open in Studio', exact: true }).evaluate((link: HTMLAnchorElement) => link.click());
  await expect(page).toHaveURL(/studio\?session=.*runId=run-return-navigation/);
  await expect.poll(() => page.evaluate(id => JSON.parse(sessionStorage.getItem(`proofui_audit_review:${id}`) || 'null')?.scrollY, run.id)).toBeCloseTo(position, 0);
  await page.reload();
  const back = page.getByRole('link', { name: 'Back to Audit' });
  await expect(back).toHaveAttribute('href', `/?runId=${run.id}`);
  await back.click();
  await expect(page.getByRole('heading', { name: 'Audit evidence', exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: /Show candidate fail issues/ })).toHaveAttribute('aria-pressed', 'true');
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeCloseTo(position, 0);
  await page.getByText('Product context used for this audit', { exact: true }).click();
  await expect(page.locator('#audit-results').getByText('Review checkout usability', { exact: true })).toBeVisible();
  await expect(page.getByRole('textbox', { name: 'Product Goal', exact: true })).toHaveValue('Review checkout usability');
  // Another run must not inherit this run's filter.
  await page.goto('/?runId=run-other');
  await expect(page.getByRole('heading', { name: 'Audit evidence', exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: /Show all issues/ })).toHaveAttribute('aria-pressed', 'true');
});

test('a saved Studio session links back to its audit without an incoming runId', async ({ page }) => {
  const run = makeUiAuditRun();
  await page.route('**/api/studio*', route => route.fulfill({ json: {
    sessions: [], session: {
      id: 'studio-saved', version: 1, createdAt: run.timestamp, model: 'gpt-6-luna',
      runs: [run], roles: ['ux'], agenda: [], roleSummaries: {}, leadSummary: '',
      roleErrors: {}, messages: [], candidates: {},
    },
  } }));
  await page.goto('/studio?session=studio-saved');
  await expect(page.getByRole('link', { name: 'Back to Audit' })).toHaveAttribute('href', `/?runId=${run.id}`);
});
